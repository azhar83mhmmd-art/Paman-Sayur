-- ============================================================
-- MINISAYUR MARKET - STORAGE SETUP
-- Jalankan SETELAH 02_rls_policies.sql
-- ============================================================

-- Create storage buckets (via Supabase Dashboard atau SQL)
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES 
  ('product-images', 'product-images', TRUE, 5242880, ARRAY['image/jpeg','image/png','image/webp','image/gif']),
  ('house-images', 'house-images', FALSE, 10485760, ARRAY['image/jpeg','image/png','image/webp'])
ON CONFLICT (id) DO NOTHING;

-- Storage policies: product-images (public bucket)
CREATE POLICY "product_images_public_read"
  ON storage.objects FOR SELECT
  USING (bucket_id = 'product-images');

CREATE POLICY "product_images_admin_upload"
  ON storage.objects FOR INSERT
  WITH CHECK (
    bucket_id = 'product-images' AND
    EXISTS(SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_admin = TRUE)
  );

CREATE POLICY "product_images_admin_update"
  ON storage.objects FOR UPDATE
  USING (
    bucket_id = 'product-images' AND
    EXISTS(SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_admin = TRUE)
  );

CREATE POLICY "product_images_admin_delete"
  ON storage.objects FOR DELETE
  USING (
    bucket_id = 'product-images' AND
    EXISTS(SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_admin = TRUE)
  );

-- Storage policies: house-images (private bucket)
CREATE POLICY "house_images_user_upload"
  ON storage.objects FOR INSERT
  WITH CHECK (
    bucket_id = 'house-images' AND
    auth.uid() IS NOT NULL
  );

CREATE POLICY "house_images_owner_read"
  ON storage.objects FOR SELECT
  USING (
    bucket_id = 'house-images' AND (
      auth.uid()::TEXT = (storage.foldername(name))[1] OR
      EXISTS(SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_admin = TRUE)
    )
  );

-- ============================================================
-- SAMPLE DATA - Produk Demo
-- ============================================================
INSERT INTO public.products (nama, harga, stok, kategori, deskripsi, image_url) VALUES
  ('Bayam Segar', 5000, 50, 'Sayuran', 'Bayam segar pilihan dari petani lokal, kaya zat besi dan vitamin.', NULL),
  ('Kangkung', 4000, 40, 'Sayuran', 'Kangkung segar siap masak, cocok untuk tumis dan pelengkap lauk.', NULL),
  ('Wortel', 8000, 35, 'Sayuran', 'Wortel manis segar, bagus untuk sup dan jus sehat.', NULL),
  ('Tomat Merah', 10000, 60, 'Buah', 'Tomat merah matang sempurna, cocok untuk masak dan salad.', NULL),
  ('Bawang Merah', 25000, 20, 'Bumbu', 'Bawang merah lokal pilihan, harum dan tidak pahit.', NULL),
  ('Bawang Putih', 20000, 25, 'Bumbu', 'Bawang putih kualitas premium, segar dan beraroma kuat.', NULL),
  ('Cabai Merah', 35000, 15, 'Bumbu', 'Cabai merah keriting segar, pedas dan harum.', NULL),
  ('Kentang', 15000, 45, 'Sayuran', 'Kentang curah segar berkualitas tinggi untuk berbagai masakan.', NULL),
  ('Telur Ayam (1 kg)', 28000, 30, 'Protein', 'Telur ayam kampung segar, isi 14-16 butir per kg.', NULL),
  ('Tahu Putih (5 pcs)', 8000, 40, 'Protein', 'Tahu putih segar, halus dan gurih untuk berbagai olahan.', NULL),
  ('Tempe (1 papan)', 7000, 35, 'Protein', 'Tempe segar dari kedelai pilihan, padat dan bernutrisi.', NULL),
  ('Beras (1 kg)', 14000, 100, 'Pokok', 'Beras pulen kualitas premium, cocok untuk nasi sehari-hari.', NULL)
ON CONFLICT DO NOTHING;
