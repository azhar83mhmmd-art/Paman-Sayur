-- ============================================================
-- MINISAYUR MARKET - KEBIJAKAN PENGGUNAAN LAYANAN
-- Terms of Service & Privacy Policy (stored as reference)
-- ============================================================

CREATE TABLE IF NOT EXISTS public.kebijakan (
  id SERIAL PRIMARY KEY,
  judul TEXT NOT NULL,
  konten TEXT NOT NULL,
  versi TEXT NOT NULL DEFAULT '1.0',
  berlaku_sejak DATE NOT NULL DEFAULT CURRENT_DATE,
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE public.kebijakan ENABLE ROW LEVEL SECURITY;

CREATE POLICY "kebijakan_public_read"
  ON public.kebijakan FOR SELECT
  USING (TRUE);

INSERT INTO public.kebijakan (judul, konten, versi, berlaku_sejak) VALUES (
  'Syarat dan Ketentuan Layanan MiniSayur Market',
  '
SYARAT DAN KETENTUAN LAYANAN
MiniSayur Market
Berlaku sejak: 2025

---

1. PENERIMAAN SYARAT
Dengan menggunakan layanan MiniSayur Market ("Platform"), Anda menyetujui syarat dan ketentuan ini sepenuhnya. Jika Anda tidak menyetujui salah satu ketentuan, harap hentikan penggunaan Platform.

2. LAYANAN YANG DISEDIAKAN
MiniSayur Market adalah platform marketplace mini yang mempertemukan pembeli dan penjual produk sayur, bahan dapur, dan kebutuhan harian rumah tangga. Platform ini bersifat sebagai fasilitator transaksi antara pembeli dan penjual.

3. PENDAFTARAN AKUN
- Pengguna wajib mendaftar menggunakan akun Google yang valid.
- Satu pengguna hanya boleh memiliki satu akun.
- Pengguna bertanggung jawab menjaga kerahasiaan akun.
- Pembuatan akun palsu atau untuk tujuan penipuan akan diblokir.

4. PEMESANAN DAN PEMBAYARAN
- Metode pembayaran yang tersedia: COD (Cash on Delivery).
- Pembayaran dilakukan saat barang diterima oleh pembeli.
- Harga yang tertera adalah harga final termasuk packaging dasar.
- Platform berhak membatalkan pesanan yang terindikasi penipuan.

5. PENGIRIMAN
- Pengiriman dilakukan ke alamat yang dicantumkan saat checkout.
- Pembeli wajib mencantumkan alamat lengkap dan foto rumah untuk memudahkan pengiriman.
- Estimasi pengiriman bergantung pada lokasi dan ketersediaan kurir.
- Risiko kerusakan produk selama pengiriman ditanggung oleh penjual.

6. PEMBATALAN DAN PENGEMBALIAN
- Pembeli dapat membatalkan pesanan selama status masih "Menunggu".
- Pengembalian produk dapat dilakukan jika: produk tidak sesuai pesanan, produk rusak/busuk saat diterima.
- Klaim pengembalian harus diajukan dalam 1x24 jam setelah produk diterima.
- Pengembalian dana untuk transaksi COD dilakukan secara manual oleh admin.

7. LARANGAN PENGGUNAAN
Pengguna dilarang:
- Membuat pesanan fiktif atau palsu.
- Menggunakan Platform untuk kegiatan ilegal.
- Menyebarkan informasi palsu mengenai produk.
- Melakukan tindakan yang merugikan pengguna lain.
- Mencoba mengakses sistem keamanan Platform.

8. PRIVASI DATA
- Data pribadi pengguna (nama, email, nomor HP, alamat) digunakan hanya untuk keperluan transaksi.
- Platform tidak menjual atau membagikan data pribadi kepada pihak ketiga tanpa persetujuan pengguna.
- Foto rumah yang diunggah hanya dapat diakses oleh admin untuk keperluan pengiriman.
- Data disimpan dengan enkripsi standar industri menggunakan layanan Supabase.

9. TANGGUNG JAWAB PLATFORM
Platform bertanggung jawab untuk:
- Menjaga ketersediaan sistem selama jam operasional.
- Memastikan keamanan data pengguna.
- Menindaklanjuti laporan penipuan atau penyalahgunaan.

Platform tidak bertanggung jawab atas:
- Kerugian akibat keterlambatan pengiriman di luar kendali Platform.
- Gangguan layanan akibat force majeure.
- Kerugian tidak langsung akibat penggunaan Platform.

10. PERUBAHAN LAYANAN
Platform berhak mengubah, menambah, atau menghentikan layanan kapan saja dengan pemberitahuan minimal 7 hari sebelumnya melalui email atau notifikasi pada Platform.

11. PENYELESAIAN SENGKETA
Sengketa antara pembeli dan penjual diselesaikan melalui mediasi admin. Jika tidak tercapai kesepakatan, penyelesaian dilakukan sesuai hukum yang berlaku di Indonesia.

12. HUKUM YANG BERLAKU
Syarat dan ketentuan ini tunduk pada hukum Republik Indonesia.

13. KONTAK
Untuk pertanyaan, keluhan, atau bantuan:
WhatsApp: +62 853-3248-9867
  ',
  '1.0',
  CURRENT_DATE
);

INSERT INTO public.kebijakan (judul, konten, versi, berlaku_sejak) VALUES (
  'Kebijakan Privasi MiniSayur Market',
  '
KEBIJAKAN PRIVASI
MiniSayur Market

---

1. DATA YANG DIKUMPULKAN
Kami mengumpulkan data berikut saat Anda menggunakan Platform:
- Nama lengkap dan alamat email (dari akun Google).
- Nomor telepon (diinput saat checkout).
- Alamat pengiriman.
- Foto rumah/lokasi pengiriman.
- Riwayat transaksi dan pesanan.

2. PENGGUNAAN DATA
Data digunakan untuk:
- Memproses dan mengantarkan pesanan.
- Mengirimkan notifikasi status pesanan.
- Meningkatkan kualitas layanan.
- Mencegah penipuan dan penyalahgunaan.

3. PENYIMPANAN DATA
- Data disimpan di server Supabase dengan enkripsi SSL/TLS.
- Data tidak disimpan di luar wilayah penyimpanan yang telah ditentukan.
- Kami menerapkan standar keamanan industri untuk melindungi data Anda.

4. HAK PENGGUNA
Anda berhak untuk:
- Mengakses data pribadi Anda.
- Meminta penghapusan akun dan data.
- Menolak pemrosesan data untuk keperluan non-esensial.

5. COOKIES
Platform menggunakan session storage untuk menyimpan preferensi pengguna dan keranjang belanja sementara. Tidak ada cookie pelacak pihak ketiga yang digunakan.

6. PERUBAHAN KEBIJAKAN
Perubahan kebijakan privasi akan diberitahukan melalui Platform atau email terdaftar.

Kontak untuk masalah privasi: +62 853-3248-9867
  ',
  '1.0',
  CURRENT_DATE
);
