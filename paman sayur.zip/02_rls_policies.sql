-- ============================================================
-- MINISAYUR MARKET - ROW LEVEL SECURITY (RLS) POLICIES
-- Jalankan SETELAH 01_schema.sql
-- ============================================================

-- Enable RLS on all tables
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.products ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.order_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.addresses ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.wishlists ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.admin_stats ENABLE ROW LEVEL SECURITY;

-- ============================================================
-- PROFILES POLICIES
-- ============================================================
CREATE POLICY "profiles_select_own"
  ON public.profiles FOR SELECT
  USING (auth.uid() = id OR 
    EXISTS(SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_admin = TRUE));

CREATE POLICY "profiles_update_own"
  ON public.profiles FOR UPDATE
  USING (auth.uid() = id);

CREATE POLICY "profiles_insert_own"
  ON public.profiles FOR INSERT
  WITH CHECK (auth.uid() = id);

-- ============================================================
-- PRODUCTS POLICIES
-- ============================================================

-- Anyone can read active products
CREATE POLICY "products_select_public"
  ON public.products FOR SELECT
  USING (is_active = TRUE OR
    EXISTS(SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_admin = TRUE));

-- Only admin can insert
CREATE POLICY "products_insert_admin"
  ON public.products FOR INSERT
  WITH CHECK (
    EXISTS(SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_admin = TRUE)
  );

-- Only admin can update
CREATE POLICY "products_update_admin"
  ON public.products FOR UPDATE
  USING (
    EXISTS(SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_admin = TRUE)
  );

-- Only admin can delete
CREATE POLICY "products_delete_admin"
  ON public.products FOR DELETE
  USING (
    EXISTS(SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_admin = TRUE)
  );

-- ============================================================
-- ORDERS POLICIES
-- ============================================================

-- Users see own orders; admin sees all
CREATE POLICY "orders_select"
  ON public.orders FOR SELECT
  USING (
    auth.uid() = user_id OR
    EXISTS(SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_admin = TRUE)
  );

-- Authenticated users can create orders
CREATE POLICY "orders_insert"
  ON public.orders FOR INSERT
  WITH CHECK (auth.uid() = user_id);

-- Admin can update status; user can cancel own
CREATE POLICY "orders_update"
  ON public.orders FOR UPDATE
  USING (
    EXISTS(SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_admin = TRUE) OR
    (auth.uid() = user_id AND status = 'menunggu')
  );

-- ============================================================
-- ORDER ITEMS POLICIES
-- ============================================================

CREATE POLICY "order_items_select"
  ON public.order_items FOR SELECT
  USING (
    EXISTS(SELECT 1 FROM public.orders WHERE id = order_id AND user_id = auth.uid()) OR
    EXISTS(SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_admin = TRUE)
  );

CREATE POLICY "order_items_insert"
  ON public.order_items FOR INSERT
  WITH CHECK (
    EXISTS(SELECT 1 FROM public.orders WHERE id = order_id AND user_id = auth.uid())
  );

-- ============================================================
-- ADDRESSES POLICIES
-- ============================================================

CREATE POLICY "addresses_select"
  ON public.addresses FOR SELECT
  USING (
    auth.uid() = user_id OR
    EXISTS(SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_admin = TRUE)
  );

CREATE POLICY "addresses_insert"
  ON public.addresses FOR INSERT
  WITH CHECK (auth.uid() = user_id);

-- ============================================================
-- WISHLISTS POLICIES
-- ============================================================

CREATE POLICY "wishlists_select_own"
  ON public.wishlists FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "wishlists_insert_own"
  ON public.wishlists FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "wishlists_delete_own"
  ON public.wishlists FOR DELETE
  USING (auth.uid() = user_id);

-- ============================================================
-- ADMIN STATS POLICIES
-- ============================================================

CREATE POLICY "admin_stats_select"
  ON public.admin_stats FOR SELECT
  USING (
    EXISTS(SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_admin = TRUE)
  );

-- ============================================================
-- REALTIME PUBLICATION
-- ============================================================

-- Enable realtime for tables
ALTER PUBLICATION supabase_realtime ADD TABLE public.products;
ALTER PUBLICATION supabase_realtime ADD TABLE public.orders;
ALTER PUBLICATION supabase_realtime ADD TABLE public.order_items;
ALTER PUBLICATION supabase_realtime ADD TABLE public.admin_stats;
